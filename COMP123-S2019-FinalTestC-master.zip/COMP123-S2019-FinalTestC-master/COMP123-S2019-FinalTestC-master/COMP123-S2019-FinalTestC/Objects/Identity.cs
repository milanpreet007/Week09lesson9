﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * STUDENT NAME:
 * STUDENT ID:
 * DESCRIPTION: This is the Identity Class to be used with the CharacterPortfolio class
 */

namespace COMP123_S2019_FinalTestC.Objects
{
    public class Identity
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
